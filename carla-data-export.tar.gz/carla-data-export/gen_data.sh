python datageneration.py --autopilot
