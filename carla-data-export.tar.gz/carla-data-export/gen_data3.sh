python3 datageneration.py --autopilot
