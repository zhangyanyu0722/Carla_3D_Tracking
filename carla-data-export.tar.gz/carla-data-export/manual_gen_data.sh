python3 datageneration.py
