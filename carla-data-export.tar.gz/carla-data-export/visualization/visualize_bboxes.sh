source activate carla_py35
python vis_utils.py -d ../../../DATA/Carla/object/ --show_image_with_boxes --vis --ind $1
